﻿The punisher  (Framework 2020 Multi-Mode Edition 2020-06-01)(hacked by zengfr)

copy压缩包roms文件夹的zip格式rom文件punisher.zip,到你安装的模拟器的roms文件夹中,重启模拟器即可。（有些模拟器需忽略文件crc校验才能正常加载）
试玩下载地址:https://zengfr.gitee.io/home/emu/punisherfr.html
2:https://gitee.com/zengfr/romhack/tree/master/hackrom
下载地址3:https://github.com/zengfr/romhack/tree/master/hackrom
游戏介绍:(hacked by zengfr)
街机punisher惩罚者框架版多模式加强(hack)
游戏特点:多模式,武器加强
1、 场景格斗时我方、敌方变身随机颜色。
2、 场景敌方随机出兵,按start可换人。
3、 场景随机物品食物武器。
4、 武器属性加强、武器不被打掉地上、耐久力、攻击力、1V2等多处细节调整。
5、 按start+up键出枪、按start+down键收枪、start+B键增加手雷。
6、 首尾关卡固定，中间随机关卡。
7、 隐藏敌兵，全部角色不动保持5秒自动唤出。
8、 尽量保持小范围移动，角色全屏反复移动会自动增兵和物品，自动增加难度。
9、 多模式Mode选择:不同模式敌兵数量和武器模式不同。
10、多模式Mode选择(00-FF):(投币后上下左右键选择不同模式After coin input, use the up, down, left and right buttons to select different modes)
        00-0F:boss+小兵+有原兵                同屏敌兵数递减:00=10 01=F 02=E 0d=D 0F=1
        10-1F:boss+小兵+无原兵                同屏敌兵数递减:10=10 11=F 12=E 1d=D 1F=1
        20-2F:boss+小兵+有原兵+无限手雷       同屏敌兵数递减:20=10 31=F 22=E 2d=D 2F=1
        30-3F:boss+小兵+无原兵+无限手雷       同屏敌兵数递减:30=10 31=F 32=E 3d=D 3F=1
        40-4F:boss+小兵+有原兵+持枪           同屏敌兵数递减:40=10 41=F 42=E 4d=D 4F=1
        50-5F:boss+小兵+无原兵+持枪           同屏敌兵数递减:50=10 51=F 52=E 5d=D 5F=1
        60-6F:boss+小兵+有原兵+持枪+无限手雷  同屏敌兵数递减:60=10 61=F 62=E 6d=D 6F=1
        70-7F:boss+小兵+无原兵+持枪+无限手雷  同屏敌兵数递减:70=10 71=F 72=E 7d=D 7F=1
        80-FF:和10-7F一致，只是中途无boss，和出兵模式有小区别。
11、试玩下载地址:https://zengfr.gitee.io/home/emu/punisherfr.html (2020.06.01后可在线试玩和rom下载)
12、试玩视频录像:https://space.bilibili.com/492484080/video
13、试玩方法:点击游戏链接,点击开始游戏按钮,开始游戏:默认按键（可自行修改:shift投币+enter开始+4方向按键+按键zxas