﻿Cadillacs and Dinosaurs (Framework 2020 Multi-Mode Edition 2020-08-09)(hacked by zengfr)

copy压缩包roms文件夹的zip格式rom文件dino.zip,到你安装的模拟器的roms文件夹中,重启模拟器即可。（有些模拟器需忽略文件crc校验才能正常加载）
试玩下载地址:https://zengfr.gitee.io/home/emu/dinofr.html
2:https://gitee.com/zengfr/romhack/tree/master/hackrom
下载地址3:https://github.com/zengfr/romhack/tree/master/hackrom
游戏介绍:(hacked by zengfr)
dino恐龙快打框架版多模式加强(hack)
游戏特点:多模式,新暴风骤雨场景
dino框架版，集成了截至目前dino各hack改版的各种特色，如彩色多层血条，攻击力暴击动态调整，敌兵变身，	   
角色同人不同色，动态出兵，boss小兵化，场景暴风骤雨打雷下雨，角色加强连击连招,同屏敌兵可按不同模式选择，
1V3 武器无限子弹等等 ，同时也是截至目前显示调试最多最全的版本，方便hack开发调试和业余玩家参考，
总之你想要特色特性得都在这里，一个rom全搞定，欢迎试玩。
(如果有隐藏敌兵卡住场景,请按1次start+b键,或我方不保持不动6秒敌兵自动自杀)
1、我方多层彩色血条，8倍血量，1V3最高难度
2、场景格斗时我方、敌方变身随机颜色
3、场景敌方随机出兵
4、场景随机物品食物武器
5、场景敌兵头部显示敌兵血量。
6、场景上方屏幕显示3P暴击数值、场景值、卷轴值、拳击计数、血量值。
7、3P身体不同颜色，同人不同色，修改默认色。
8、暴击出场值0x50,被打-2,加血+8，最高60，最低50，AB双倍耗血。
9、 jack加强:B跳高增强、前前A远距离滑铲前冲、前前BA全屏距离远跳
10、3P连击出招加强:4拳连击后,自动下上A出击
11、部分场景暴风骤雨下雨打雷暴雨
12、按投币键8个币过关(第3关除外)、按start+b键出武器、start+A键增兵
13、多模式Mode选择:不同模式敌兵数量和武器模式不同
14、多模式Mode选择:(投币后上下键选择不同模式Up and down keys to choose different modes after coin insertion)
    0A-0F:boss+死后变身           同屏敌兵数递增:0a=3 0b=4 0c=5 0d=6 0f=8
	10-19:boss+死后不变身         同屏敌兵数递增:10=3 11=1 12=2 13=3 19=9
	20-29:boss+枪支武器无限弹药   同屏敌兵数递增:20=3 21=1 22=2 23=3 29=9
	3A-3F:小兵+boss+死后变身           同屏敌兵数递增:3a=3 3b=4 3c=5 3d=6 3f=8
	40-49:小兵+boss+死后不变身         同屏敌兵数递增:40=3 41=1 42=2 43=3 49=9
	50-59:小兵+boss+枪支武器无限弹药   同屏敌兵数递增:50=3 51=1 52=2 53=3 59=9
15、试玩下载地址:https://zengfr.gitee.io/home/emu/dinofr.html (2020.03.25后可在线试玩和rom下载)
16、试玩视频录像:https://space.bilibili.com/492484080/video
17、试玩方法:点击游戏链接,点击开始游戏按钮,开始游戏:默认按键（可自行修改:shift投币+enter开始+4方向按键+按键zxas